#ifndef SYMLINK_READLINK_H_
#define SYMLINK_READLINK_H_
#include "type.h"

int symlink(char * old_file, char * new_file); 

int readlink(char * filename, char * mbuf); 



#endif