#ifndef STAT_H_
#define STAT_H_
#include "type.h"

int mstat(char *pathname); 


#endif