#include "symlink_readlink.h"

int symlink(char * old_file, char * new_file)
{
    int oldino = getino(old_file);
    int newino = getino(new_file); 
    char parent[128]; 
    char child[128]; 
    char temp[128]; //our pathname can be at most twice the size of the dirname and basename so 64 * 2 = 128 bits needed
    int pino; 
    MINODE * newmip; 
    // char mode[10] = "0120000"; 
    MINODE * oldmip =  iget(dev, oldino); 

    // char oldfilename[60]; 
    // strcpy(oldfilename, basename(old_file)); 

    char mbuf[BLKSIZE]; 

    //new file must not exist yet and oldfile must not be a dir
    if(!S_ISDIR(oldmip->INODE.i_mode))
    {
        if(newino == 0)//hasn't been assigned yet
        {
            printf("Creating Sym FILE\n"); 
            _creat(new_file, LNK_MODE); //it is a link type now, modified my creat to take a mode to set instead of default to FILEMODE when called
            newino = getino(new_file); 
            newmip = iget(dev, newino); 
            strcpy(temp, old_file); //so we don't destroy pathname
            strcpy(child,basename(temp)); //destructive
            strcpy(temp, old_file); 
            strcpy(parent,dirname(temp)); // pino = getino(parent); // pmip = iget(dev, pino); //enter_name(pmip, oldino, child, FILE_MODE);//extra parameter to make sure the type is file, there may be different ways to do this, but this is how I chose to do it//pmip->INODE.i_mode += (int)strtol(mode, NULL, 8);//convert a file type to link type

            get_block(dev, newmip->INODE.i_block[0], mbuf);
            strcpy(mbuf, child);
            //printf("MYBUF == %s\n", mbuf); 
            put_block(dev, newmip->INODE.i_block[0], mbuf); 
            newmip->INODE.i_size = strlen(child); 

            /*
            //store the name of the old file in the new nodes iblock
            //not completely sure how to do this
            //pmip->INODE.i_block[0] =
            //set size to the length of old files name
            //newmip->INODE.i_size = strlen(oldfilename); 
            */
            
            oldmip->dirty = 1; 
            iput(oldmip); //put back the two INODEs we used
            newmip->dirty = 1; 
            iput(newmip); 
        }
        else{
            printf("This FILE already exists\n");
        }
    }
    else {
        printf("OLDFILE must be a FILE\n"); 
    }



}

int readlink(char * filename  ,char * mbuf)
{
    int ino = getino(filename); 
    MINODE * mip = iget(dev, ino); 

    if (S_ISLNK(mip->INODE.i_mode))
    {
        //not to0 sure about this part, but I think this is correct as it only contains a name less than 60 so it should be in the first block
        get_block(dev, mip->INODE.i_block[0], mbuf); //strcpy(buf,mip->INODE.i_block[0]);//get the file and copy it into the buf
        
        //we probably need to use get block. but if its a dir, then isn't that the same as making an entry need to check if that is right
        printf("Read %s\n", mbuf); 
        return mip->INODE.i_size; 
    }
    else{
        printf("Must be a LNK");
    }




} 
