#ifndef RMDIR_H_
#define RMDIR_H_
#include "type.h"
#include "util.h"
// globals
extern MINODE minode[NMINODE];
extern MINODE *root;

extern PROC   proc[NPROC], *running;

extern char gpath[128]; // global for tokenized components
extern char *name[32];  // assume at most 32 components in pathname
extern int   n;         // number of component strings

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, inode_start;

int _rmdir(char * pathname); 

int rm_child(MINODE * pmip, char *rname); 

#endif