#include "open_close_lseek.h"

int myopen(char * filename, int flags)
{
    int ino = getino(filename);
    MINODE *mip; 
    //printf("IN MY OPEN\n"); 
    if (ino == 0)//if the file doesn't exist create a new one
    {
        _creat(filename, FILE_MODE); 
        ino = getino(filename); //get the newly created file
    }
    mip = iget(dev, ino); 
    int i = 0; 
    for (i = 0; i < NOFT; i++)
    {
        if (oft[i].mptr == NULL)
        {
            break; 
        }    
    }

    oft[i].mode = flags; //set the files mode based off the flag
    oft[i].mptr = mip; //assign the mip to the lowest file descriptor
    oft[i].refCount = 1; //set the reference count

    if(flags == 0)
    {
        //read 
        oft[i].offset = 0; //start with no ofset 
    }
    else if (flags == 1)
    {
        //write
        oft[i].offset = 0; //start with no ofset
    }
    else if (flags == 2)
    {
        //read and write
        oft[i].offset = 0; //start with no ofset at the begining 
    }
    else if (flags == 3)
    {
        //append
        oft[i].offset = mip->INODE.i_size; //start at the end of the file size for append
    }
    //printf("BEFORE OPEN LOOP\n"); 
    for(int j = 0; j < NFD; j++)
    {
        //printf("j == %d\n", j);
        //lowest fd points to the oft entry
        if (running->fd[j] == NULL)//we found lowest file entry
        {
            running->fd[j] = &oft[i]; 
            return j; 
        }
    }
}

int mylseek(int fd, int position)
{
    if(position >= 0 && (position < running->fd[fd]->mptr->INODE.i_size-1))
    {
        running->fd[fd]->offset = position;
        return position; // we set the position
    }
    else{
        printf("We can't change to start at this position, it is outside of our bounds\n");
        return 0; //we didn't set the position
    }
}

int myclose(int fd)
{
    if(running->fd[fd] != NULL)//points at an open file descriptor
    {
        running->fd[fd]->refCount--; //decrement our refcount
        if (running->fd[fd]->refCount == 0)
        {
            iput(oft->mptr);//not in use so we can just put it back
        }
    }
    running->fd[fd] = NULL; 
    return 0; 
}