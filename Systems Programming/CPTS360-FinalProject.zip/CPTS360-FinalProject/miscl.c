#include "miscl.h"

int mchmod(char * mode, char * pathname)
{
    //format chmod octal(mode) pathname
    // printf("Path %s\n", pathname);
    // printf("Mode %s\n", mode); 

    // mode == rwx|rwx|rwx == 0644 in octal
    int ino = getino(pathname); 
    if (ino != 0)
    {
        MINODE *mip = iget(dev, ino); 
        //works for octal numbers
        mip->INODE.i_mode |= (int)strtol(mode, NULL, 8); //I take in a string and convert it to octol rather than octal. Or the bits to change to one or keep if already one
        mip->dirty = 1; 
        iput(mip); 
    }
    else{
        printf("Not a valid file or directory\n"); 
    }
    
}


int access(char * pathname)
{
    int ino = getino(pathname);
    if (ino != 0)
    { 
        MINODE *mip = iget(dev, ino); 
        printf("Mode %d, User ID %d, Group ID = %d, Flags %d\n", mip->INODE.i_mode, mip->INODE.i_uid, mip->INODE.i_gid, mip->INODE.i_flags); 
        mip->dirty = 1; 
        iput(mip); 
    }
    else{
        printf("Not a valid file or directory\n"); 
    }
}

int chown(char *newowner, char * pathname)
{
    int ino = getino(pathname); 
    if (ino != 0)
    {
        MINODE *mip = iget(dev, ino); 
        mip->INODE.i_uid = atoi(newowner);//change the owner id 
        mip->dirty = 1; 
        iput(mip); 
    }
    else{
        printf("Not a valid file or directory\n"); 
    }
}

int chtime(char * pathname)
{
    int ino = getino(pathname);
    //printf("INO = %d\n", ino); 
    if (ino != 0)
    {
        MINODE *mip = iget(dev, ino); 
        mip->INODE.i_atime = time(0L); // a time is not displayed by ls
        //theoretically I should be changing atime, but the functions aren't actually printing anything even though it works for c_time
        mip->dirty = 1; 
        iput(mip); 
    }
    else{
        printf("Not a valid file or directory\n"); 
    }
}