#include "link_unlink.h"
//link works properly
int link(char * oldfile, char * newfile)
{
    int oldino = getino(oldfile);
    int newino = getino(newfile); 
    char parent[128]; 
    char child[128]; 
    char temp[128]; //our pathname can be at most twice the size of the dirname and basename so 64 * 2 = 128 bits needed
    int pino; 
    MINODE * pmip; 

    MINODE * oldmip =  iget(dev, oldino); 
    //new file must not exist yet and oldfile must not be a dir
    if(!S_ISDIR(oldmip->INODE.i_mode))
    {
        if(newino == 0)//hasn't been assigned yet
        {
            strcpy(temp, newfile); //so we don't destroy pathname
            strcpy(child,basename(temp)); //destructive
            strcpy(temp, newfile); 
            strcpy(parent,dirname(temp)); 
            pino = getino(parent); 
            pmip = iget(dev, pino); 
            enter_name(pmip, oldino, child, FILE_MODE);//extra parameter to make sure the type is file, there may be different ways to do this, but this is how I chose to do it
            oldmip->INODE.i_links_count++; 
            oldmip->dirty = 1; 
            iput(oldmip); //put back the two INODEs we used
            iput(pmip); 

        }
        else{
            printf("This FILE already exists\n");
        }
    }
    else {
        printf("OLDFILE must be a FILE\n"); 
    }




} 

int unlink(char * pathname)
{
    int ino = getino(pathname); 
    MINODE * mip = iget(dev, ino); 
    char parent[128];
    char temp[128]; 
    char child[128];  
    int pino; 
    MINODE *pmip; 
    if(!S_ISDIR(mip->INODE.i_mode))
    {
        strcpy(temp, pathname); //so we don't destroy pathname
        strcpy(child,basename(temp)); //destructive
        strcpy(temp, pathname); 
        strcpy(parent,dirname(temp));
        pino = getino(parent); 
        pmip = iget(dev, pino); 
        //rm is not implemented, but when it is 
        rm_child(pmip,child); 
        pmip->dirty = 1;
        iput(pmip); 
        mip->INODE.i_links_count--; //decrement the link count
        if(mip->INODE.i_links_count > 0)
        {
            mip->dirty = 1; 
        }
        else{//if links is zero remove it
            for(int j = 0; j < 12; j++)//deallocate the blocks
            {
                bdalloc(mip->dev, mip->INODE.i_block[j]);
            }
            idalloc(mip->dev, ino); 
            mip->dirty = 1; 
            //deallocate INODE

        }

        iput(mip); //release mip


    }
    else {
        printf("Must be a FILE\n"); 
    }
}