#ifndef MISCL_H_
#define MISCL_H_
#include "type.h"

int mchmod(char * mode, char * pathname); 

int access(char * pathname); 

int chown(char *newowner, char * pathname); 

int chtime(char * pathname); 




#endif