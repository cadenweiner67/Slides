#ifndef CD_LS_PWD_H_
#define CD_LS_PWD_H_
#include "type.h"

int mchdir(char *pathname);

int ls_file(MINODE *mip, char *name);

int ls_dir(MINODE *mip);

int ls(char *pathname);

void rpwd(MINODE *wd);

char *pwd(MINODE *wd);

#endif