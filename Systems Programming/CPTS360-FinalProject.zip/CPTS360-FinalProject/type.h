/*************** type.h file ************************/
#ifndef CD_LS_PWD_H_
#define CD_LS_PWD_H_

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ext2fs/ext2_fs.h>
#include <string.h>
#include <libgen.h>
#include <sys/stat.h>
#include <time.h>

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;

typedef struct ext2_super_block SUPER;
typedef struct ext2_group_desc  GD;
typedef struct ext2_inode       INODE;
typedef struct ext2_dir_entry_2 DIR;

SUPER *sp;
GD    *gp;
INODE *ip;
DIR   *dp;

#define FREE        0
#define READY       1

#define BLKSIZE  1024
#define NMINODE   128 // duplicate
#define NFD        16 // duplicate
#define NPROC       2 // duplicate

#define NMTABLE 10
#define NOFT 40 

#define DIR_MODE 0x41ED
#define FILE_MODE 33188
#define LNK_MODE 0120444

#define SUPER_MAGIC 0xEF53
#define SUPER_USER 0
#define FREE 0
#define BUSY 1


typedef struct minode{
  INODE INODE;
  int dev, ino;
  int refCount;
  int dirty;
  int mounted;
  struct mntable *mptr;
}MINODE;

typedef struct oft{
  int  mode;
  int  refCount;
  MINODE *mptr;
  int  offset;
}OFT;

typedef struct proc{
  struct proc *next;
  int          pid;
  int          ppid;
  int          status;
  int          uid, gid;
  MINODE      *cwd;
  OFT         *fd[NFD];
}PROC;

typedef struct mtable{
  int dev; 
  int ninodes; 
  int nblocks; 
  int free_blocks;
  int free_inodes;
  int bmap;
  int imap;
  int iblock;
  MINODE *mntDirPtr;
  char devName[64];
  char mntName[64];

}MTABLE; 

extern int dev; 
extern OFT oft[NOFT]; 
extern MTABLE mtable[NMTABLE]; 
extern PROC proc[NPROC], *running;
#endif