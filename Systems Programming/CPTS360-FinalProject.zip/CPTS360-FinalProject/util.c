/*********** util.c file ****************/
#include "util.h"

int get_block(int dev, int blk, char *buf)
{
   lseek(dev, (long)blk*BLKSIZE, 0);
   int n = read(dev, buf, BLKSIZE);
   if (n < 0)
   {
     printf("get_block [%d %d] error\n", dev, blk);
   }
}
int put_block(int dev, int blk, char *buf)
{
   lseek(dev, (long)blk*BLKSIZE, 0);
   int n = write(dev, buf, BLKSIZE);
   if (n != BLKSIZE)
   {
     printf("put_block [%d %d] error\n", dev, blk);
   }
}

int tokenize(char *pathname)
{
  char *s;
  strcpy(gpath, pathname);
  n = 0;
  s = strtok(gpath, "/");
  while(s)
  {
    name[n++] = s;
    s = strtok(0, "/");
  }
}

// Had to move this too a function from iget loop because otherwise we passed back the last free node instead of the first.
MINODE *getFreeMINODE()
{
    for (int i = 0; i < NMINODE; i++) // loop through all of minode
    {
        MINODE *mp = &minode[i];
        if (mp->refCount == 0) // if finds a node that is unallocated already
        {
            mp->refCount = 1;
            return mp;
        }
    }
    printf("edge case: ran out of minodes\n");
    return 0;
}

MINODE *iget(int dev, int ino)
{
  MINODE *mip, mp;
  int i, block, offset;
  char buf[BLKSIZE];
  // search in-memory minodes first
  for (i=0; i<NMINODE; i++)
  {
    MINODE *mip = &minode[i];
    if (mip->refCount && (mip->dev==dev) && (mip->ino==ino))
    {
      mip->refCount++;
      return mip;
    }
  }
  // allocate a FREE minode
  mip = getFreeMINODE();
  mip->dev = dev;  // set the device to current
  mip->ino = ino;  // assign to (dev, ino)
  block = (ino - 1) / 8 + inode_start;  // find the block to read from
  offset = (ino - 1) % 8;
  get_block(dev, block, buf);  // read the block
  ip = (INODE *)buf + offset;
  mip->INODE = *ip;  // set pointer to block
  mip->dirty = 0;
  mip->mptr = 0;
  mip->mounted = 0;
  mip->refCount = 1;
  return mip;
}

void iput(MINODE *mip)
{
  INODE *ipp;
  int i, block, offset;
  char buf[BLKSIZE];
  if (mip==0) return;
  mip->refCount--;
  if (mip->refCount > 0) return;
  if (mip->dirty == 0) return;
  // dec refCount by 1
  // still has user
  // no need to write back
  // write INODE back to disk
  block = (mip->ino - 1) / 8 + inode_start;
  offset = (mip->ino - 1) % 8;
  // get block containing this inode
  get_block(mip->dev, block, buf);
  ipp = (INODE *)buf + offset;
  *ipp = mip->INODE;
  put_block(mip->dev, block, buf); //writes the block back to the disk
  mip->refCount = 0;//sets the reference count back to zero
  return;
  // ip points at INODE
  // copy INODE to inode in block
  // write back to disk
}

int search(MINODE *mip, char *name)
{
  int i;
  char *cp, temp[256], sbuf[BLKSIZE];
  DIR *dp;
  for (i=0; i<12; i++){ // search DIR direct blocks only
    if (mip->INODE.i_block[i] == 0) return 0;
    get_block(mip->dev, mip->INODE.i_block[i], sbuf);
    dp = (DIR *)sbuf;
    cp = sbuf;
    while (cp < sbuf + BLKSIZE)
    {
      strncpy(temp, dp->name, dp->name_len);
      temp[dp->name_len] = 0;
      printf("%8d%8d%8u %s\n",
      dp->inode, dp->rec_len, dp->name_len, temp);
      if (strcmp(name, temp)==0)
      {
        printf("found %s : inumber = %d\n", name, dp->inode);
        return dp->inode;
      }
      cp += dp->rec_len;
      dp = (DIR *)cp;
    }
  }
  return 0;
}


int getino(char *pathname)
{
  MINODE *mip;
  int i, ino;
  if (strcmp(pathname, "/")==0)
  {
  return 2;
  // return root
  // ino=2
  }
  if (pathname[0] == '/')
  {
    mip = root;
  }// if absolute
  else
  {
    mip = running->cwd;// if relative
  }
  mip->refCount++;
  // in order to
  tokenize(pathname);
  //pathname: start from root
  //pathname: start from CWD
  //iput(mip) later
  // assume: name[ ], n are globals
  for (i=0; i<n; i++)
  {
    // search for each component string
    if (!S_ISDIR(mip->INODE.i_mode))
    { // check DIR type
      printf("%s is not a directory\n", name[i]);
      iput(mip);
      return 0;
    }
    ino = search(mip, name[i]);
    if (!ino)
    {
      printf("no such component name %s\n", name[i]);
      iput(mip);
      return 0;
    }
    iput(mip);
    // release current minode
    mip = iget(dev, ino);
    // switch to new minode
  }
  iput(mip);
  return ino;
}

//not sure if this works yet, in progress, Caden
//I think it should work, just haven't got a chance to test it yet
int findmyname(MINODE *parent, u32 myino, char *myname)
{
  char *cp, temp[256], sbuf[BLKSIZE]; // variables for addressing and buffers
  DIR *dp;
  //INODE inode = parent->INODE;
  for (int i=0; i<12; i++){ // search DIR direct blocks only
    if (parent->INODE.i_block[i] == 0) return 0;
    get_block(parent->dev, parent->INODE.i_block[i], sbuf);
    dp = (DIR *)sbuf;
    cp = sbuf;
    while (cp < sbuf + BLKSIZE)
    {
      strncpy(temp, dp->name, dp->name_len);
      temp[dp->name_len] = 0;
      printf("%8d%8d%8u %s\n",dp->inode, dp->rec_len, dp->name_len, temp);
      if (dp->inode == myino)
      {
        strcpy(myname, temp);    //updates our myname value
        printf("myname is %s : inumber = %d\n", myname, dp->inode);
        return dp->inode;
      }
      cp += dp->rec_len; //adds the ofset to the address of cp for the next item to read from
      dp = (DIR *)cp; // updates the directory to read from
    }
  }
  return 0;
  //strcpy(myname, temp);
  //something like
  //parent->INODE; //now search data of inode

}


int findino(MINODE *mip, u32 *myino) // myino = ino of . return ino of ..
{
  // mip->a DIR minode. Write YOUR code to get mino=ino of .
  //                                         return ino of ..
  //will require a call to getblock
  char *cp, sbuf[BLKSIZE];
  DIR *parentdp;
  get_block(mip->dev, mip->INODE.i_block[0], sbuf);
  cp = sbuf; //assigns the address of cp to sbuf
  parentdp = (DIR *)sbuf;
  *myino = parentdp->inode;
  cp += parentdp->rec_len;
  parentdp = (DIR *)cp; //the shift address gets the next dir
  return parentdp->inode;
}

//allocates an inode
int ialloc(int dev)
{
  char buf[BLKSIZE];

  get_block(dev, imap, buf); //gets the imap block
  for (int i = 0; i < ninodes; i++)
  {
    if (tst_bit(buf, i) == 0)//test the bit to find the first free bit
    {
      set_bit(buf, i); //set the bit
      put_block(dev, imap, buf); //release the block
      decFreeInodes(dev); //we found it so we know there are less free bits
      return (i + 1);//we count 1 beyond in other areas that use it
    }

  }
  return 0; //not found
}

//allocates a block
int balloc(int dev)
{
  char buf[BLKSIZE];

  get_block(dev, bmap, buf); //gets the imap block
  for (int i = 0; i < nblocks; i++)
  {
    if (tst_bit(buf, i) == 0)//tst the bit to find the first free bit
    {
      set_bit(buf, i); //set the bit
      put_block(dev, bmap, buf); //release the block
      decFreeBlocks(dev); //we found it so we know there are less free bits
      return (i + 1);//we count 1 beyond in other areas that use it
    }
  }
  return 0; //not found
}

int tst_bit(char * buf, int bit)
{
  return buf[bit/8] & (1 << (bit % 8));
}

int set_bit(char * buf, int bit)
{
  buf[bit/8] |= (1 << (bit % 8));//set the bit
}
//maybe an issue here?
int decFreeInodes(int dev)
{
  char buf[BLKSIZE];
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;
  sp->s_free_inodes_count--;
  put_block(dev, 1, buf);
  get_block(dev, 2, buf);
  gp = (GD *)buf;
  gp->bg_free_inodes_count--;
  put_block(dev, 2, buf);
}

int decFreeBlocks(int dev)//needs to be altered
{
  char buf[BLKSIZE];
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;
  sp->s_free_blocks_count--;
  put_block(dev, 1, buf);
  get_block(dev, 2, buf);
  gp = (GD *)buf;
  gp->bg_free_blocks_count--;
  put_block(dev, 2, buf);
}

int incFreeInodes(int dev)
{
  char buf[BLKSIZE];
  // inc free inodes count in SUPER and GD
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;
  sp->s_free_inodes_count++;
  put_block(dev, 1, buf);
  get_block(dev, 2, buf);
  gp = (GD *)buf;
  gp->bg_free_inodes_count++;
  put_block(dev, 2, buf);
}

int incFreeBlocks(int dev)//needs to be altered
{
  char buf[BLKSIZE];
  // inc free inodes count in SUPER and GD
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;
  sp->s_free_inodes_count++;
  put_block(dev, 1, buf);
  get_block(dev, 2, buf);
  gp = (GD *)buf;
  gp->bg_free_inodes_count++;
  put_block(dev, 2, buf);
}

int clr_bit(char * buf, int bit)
{
  buf[bit/8] &= ~(1 << (bit%8));
}

int idalloc(int dev, int ino)
{
  int i;
  char buf[BLKSIZE];

  if (ino > ninodes){ // niodes global
    printf("inumber %d out of range\n", ino);
    return;
  }
  // get inode bitmap block
  get_block(dev, imap, buf);
  clr_bit(buf, ino-1);
  // write buf back
  put_block(dev, imap, buf);
  // update free inode count in SUPER and GD
  incFreeInodes(dev);
}

int bdalloc(int dev, int blocknum)
{
    char buf[BLKSIZE];
    get_block(dev, bmap, buf);
    clr_bit(buf, blocknum - 1);
    put_block(dev, bmap, buf);
    incFreeBlocks(dev);
    return;
}

int get_mtable(dev)
{
  return &mtable[0]; //this likely needs more modification
}


int _map(INODE inode, int lblk)
{
    printf("MAP BEGIN\n"); 
    int blk = 0; 
    if (lblk < 12)
    {
        blk = inode.i_block[lblk]; 
    }
    else if (12 <= lblk < 12 + 256){
        //read inode iblock 12 into int ibuf 256
        //blk = ibuf[lblk-12]; // not implemented yet
        
    }
    else {
        //double indirect blocks
        //not implemented yet
    }
    printf("MAP SUCCESSFUL\n"); 
    return blk;
}
