/************* cd_ls_pwd.c file **************/

int chdir(char *pathname)
{
  printf("chdir %s\n", pathname);
  int chino;
  chino = getino(pathname);
  if (chino == 0)
  {
    printf("Error inode = %d\n", chino);
    return -1;
  }
  MINODE * mip = iget(dev, chino);
  if (!S_ISDIR(mip->INODE.i_mode))
  {
    printf("Is not a directory\n");
    return -1;
  }
  printf("Is a directory\n");
  iput(running->cwd); // release old cwd
  running->cwd = mip; // updates the current workign directory

  return 1; //completed successfully
}

int ls_file(MINODE *mip, char *name)
{
  //printf("ls_file: to be done: READ textbook for HOW TO!!!!\n");
  // strcpy(ftime, ctime(mip->INODE.i_ctime))
  //file type
  if (S_ISDIR(mip->INODE.i_mode))
  {
    printf("d");
  }
  else if (S_ISLNK(mip->INODE.i_mode))
  {
    printf("l");
  }
  else if (S_ISREG(mip->INODE.i_mode))
  {
    printf("-");
  }
  
  //will print out the symbol if they have access
  //otherwise prints
  //goes from left to right, since we print
  //one at a time, we must print the left mostbits first
  if (mip->INODE.i_mode & (1 << 8)) //bit wise logical shift left compair the bits with those in the dir
  {
    printf("r");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 7))
  {
    printf("w");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 6))
  {
    printf("x");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 5))
  {
    printf("r");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 4))
  {
    printf("w");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 3))//compair bits
  {
    printf("x");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 2))//compairs bits
  {
    printf("r");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 1))//compairs bits
  {
    printf("w");
  }
  else
  {
    printf("-");
  }
  if (mip->INODE.i_mode & (1 << 0))//compairs bits
  {
    printf("x");
  }
  else
  {
    printf("-");
  }

  printf(" %o %d %d %s %d %s",mip->INODE.i_mode, mip->INODE.i_links_count, mip->INODE.i_gid,name,mip->INODE.i_size , ctime(&mip->INODE.i_mtime));

}

int ls_dir(MINODE *mip)
{
  //printf("ls_dir: list CWD's file names; YOU do it for ls -l\n");

  char buf[BLKSIZE], temp[256];
  DIR *dp;
  char *cp;

  // Assume DIR has only one data block i_block[0]
  // for (int i = 0; i < 12; i++)
  // {
    //if(mip->INODE.i_block[i]==0) break; 
    get_block(dev, mip->INODE.i_block[0], buf);
    dp = (DIR *)buf;
    cp = buf;

    while (cp < buf + BLKSIZE){
      strncpy(temp, dp->name, dp->name_len);
      temp[dp->name_len] = 0;

      //printf("[%d x %s]  \n", dp->inode, temp); // print [inode# name]

      mip = iget(dev, dp->inode);
      ls_file(mip, temp);
      //printf("Rec = %d, Size = %d\n", dp->rec_len,dp->name_len);

      cp += dp->rec_len;
      dp = (DIR *)cp;

    }
    printf("\n");
  //}
}

int ls(char *pathname)
{
  printf("ls %s\n", pathname);
  // need to search for the pathname here and then feed its
  //minode into ls_dir // this is a util.c function
  if (strcmp("",pathname)==0)
  {
    ls_dir(running->cwd);
  }
  else
  {
    int ino;
    // if pathname doesn't exist, print an error.
    if ((ino = getino(pathname)) == -1)
    {
      printf("ls: cannot access '%s': No such file or directory", pathname);
      return -1;
    }
    dev = root->dev;
    MINODE *mip = iget(dev,ino);
    int type = mip->INODE.i_mode;
    // otherwise get the pathname and check if its a file or a dir.
    // if its a dir run the ls_dir
    if (S_ISDIR(type))
    {
      ls_dir(mip);
    }
    // else run the ls-file
    else
    {
      ls_file(mip, pathname);
    }
  }
  return;
}

void rpwd(MINODE *wd)
{
  char rbuf[BLKSIZE];
  int myino;
  int parentino = findino(wd, &myino); //get parent ino

  char my_name[256];
  char * cp;

  if (wd == root)
  {
    return;
  }
  else
  {
    //printf("Completed a cycle");
    MINODE * pip = iget(dev, parentino);
    get_block(dev, wd->INODE.i_block[0], rbuf);
    DIR * dp = (DIR *)rbuf;
    myino = dp->inode; //gets the inode of the current block
    cp = rbuf;
    pip = iget(dev, parentino); //get the parent minode
    //printf("Completed a cycle");
    get_block(dev, pip->INODE.i_block[0], rbuf);
    dp = (DIR *) rbuf; //updates dp based off new rbuf
    cp = rbuf; //updates cp in case rbuf changed
    //printf("Completed a cycle");
    while (rbuf + BLKSIZE > cp)
    {
      if (myino == dp->inode)// checks if the dp offset is the current inode, looking through the directory for the current inode name
      {
        strncpy(my_name, dp->name, dp->name_len);
        my_name[dp->name_len] = '\0'; //set last char to null
        break;
      }
      else
      {
        cp += dp->rec_len; //shift where we are pointing to the next dir entry
        dp = (DIR*) cp; //gets the dir entry
      }
    }

    rpwd(pip);
    printf("/%s", my_name);
  }
}

char *pwd(MINODE *wd)
{
  if (wd == root){
    printf("/");
  }
  else{
    rpwd(wd);
  }
  printf("\n");
  return;
}



