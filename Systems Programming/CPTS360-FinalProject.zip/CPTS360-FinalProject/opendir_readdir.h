#ifndef OPEN_CLOSE_LSEEK_H_
#define OPEN_CLOSE_LSEEK_H_
#include "type.h"

int opendir(char * pathname);

int myreaddir(int fd, DIR *udir); 



#endif