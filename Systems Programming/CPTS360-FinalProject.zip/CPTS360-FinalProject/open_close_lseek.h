#ifndef OPEN_CLOSE_LSEEK_H_
#define OPEN_CLOSE_LSEEK_H_
#include "type.h"
#include "util.h"
int myopen(char * filename, int flags); 

int mylseek(int fd, int position); 

int myclose(int fd); 


#endif