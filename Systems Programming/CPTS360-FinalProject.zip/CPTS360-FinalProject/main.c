/****************************************************************************
*                   ext2 file system                            *
*****************************************************************************/
#include "type.h"
#include "util.c"
#include "cd_ls_pwd.c"
#include "mk_creat.c"
#include "link_unlink.c"
#include "rmdir.c"
#include "miscl.c"
#include "stat.c"
#include "symlink_readlink.c"
#include "read.c"
#include "write.c"
#include "open_close_lseek.c"

//not sure if these should be in main yet
// #include "miscl.c"
// #include "mount_unmount.c"
// #include "read.c"
// #include "write.c"


// globals
MINODE minode[NMINODE];
MINODE *root;

PROC   proc[NPROC], *running;

char gpath[128]; // global for tokenized components
char *name[32];  // assume at most 32 components in pathname
int   n;         // number of component strings

int fd, dev;
int nblocks, ninodes, bmap, imap, inode_start;

MINODE *iget();
//MTABLE mtable[NMTABLE]; 
OFT oft[NOFT]; 
MTABLE mtable[NMTABLE]; 

int init()
{
  int i, j;
  MINODE *mip;
  PROC   *p;

  printf("init()\n");

  for (i=0; i<NMINODE; i++){
    mip = &minode[i];
    mip->dev = mip->ino = 0;
    mip->refCount = 0;
    mip->mounted = 0;
    mip->mptr = 0;
  }
  for (i=0; i<NPROC; i++){
    p = &proc[i];
    p->pid = i;
    p->uid = p->gid = 0;
    p->cwd = 0;
    p->status = FREE;
    for (j=0; j<NFD; j++)
      p->fd[j] = 0;
  }

  for (i=0; i<NMTABLE; i++)
  {
    mtable[i].dev = 0;  
  }
  
}

// load root INODE and set root pointer to it

int mount_root()
{
  
  int i;
  int iblock; 
  MTABLE *mp;
  SUPER *sp;
  GD *gp;
  char buf[BLKSIZE];
    // circular list
  // P0 runs first
  // mount root file system
  //dev = open(rootdev, O_RDWR);
  if (dev < 0){
    printf("panic : can’t open root device\n");
    exit(1);
  }
  printf("DEV = %d\n", dev); 
  
  /* get super block of rootdev */
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;
  /* check magic number */
  if (sp->s_magic != SUPER_MAGIC){
    printf("super magic=%x : %d is not an EXT2 filesys\n",
    sp->s_magic, dev);
    exit(0);
  }
  // fill mount table mtable[0] with rootdev information
  mp = &mtable[0];
  // use mtable[0]
  mp->dev = dev;
  // copy super block info into mtable[0]
  ninodes = mp->ninodes = sp->s_inodes_count;
  nblocks = mp->nblocks = sp->s_blocks_count;
  
  
  //this code expects dev to be a name not a fd
  //strcpy(mp->devName, dev);
  
  
  strcpy(mp->mntName, "/");

  get_block(dev, 2, buf);
  gp = (GD *)buf;
  bmap = mp->bmap = gp->bg_block_bitmap;
  imap = mp->imap = gp->bg_inode_bitmap;
  iblock = mp->iblock = gp->bg_inode_table;
  printf("bmap=%d imap=%d iblock=%d\n", bmap, imap, iblock);
  // call iget(), which inc minode’s refCount
  
  root = iget(dev, 2);
  // get root inode
  mp->mntDirPtr = root;
  // double link
  root->mptr = mp;
  // set proc CWDs
  for (i=0; i<NPROC; i++)
  {
    proc[i].cwd = iget(dev, 2); 
  }
  // each inc refCount by 1
  printf("mount : %d mounted on / \n", dev);
  return 0;
}



char *disk = "diskimage";
int main(int argc, char *argv[ ])
{
  int ino;
  char buf[BLKSIZE];
  char ebuf[128]; 
  char line[128], cmd[32], pathname[128];

  if (argc > 1)
  {
    disk = argv[1];
  }

  printf("checking EXT2 FS ....");
  if ((fd = open(disk, O_RDWR)) < 0){
    printf("open %s failed\n", disk);
    exit(1);
  }
  dev = fd;

  /********** read super block  ****************/
  get_block(dev, 1, buf);
  sp = (SUPER *)buf;

  /* verify it's an ext2 file system ***********/
  if (sp->s_magic != 0xEF53){
      printf("magic = %x is not an ext2 filesystem\n", sp->s_magic);
      exit(1);
  }
  printf("EXT2 FS OK\n");
  ninodes = sp->s_inodes_count;
  nblocks = sp->s_blocks_count;

  get_block(dev, 2, buf);
  gp = (GD *)buf;

  bmap = gp->bg_block_bitmap;
  imap = gp->bg_inode_bitmap;
  inode_start = gp->bg_inode_table;
  printf("bmp=%d imap=%d inode_start = %d\n", bmap, imap, inode_start);

  init();
  mount_root();
  printf("root refCount = %d\n", root->refCount);

  printf("creating P0 as running process\n");
  running = &proc[0];
  running->status = READY;
  running->cwd = iget(dev, 2);
  printf("root refCount = %d\n", root->refCount);

  while(1){
    printf("input command : [ls|cd|pwd|mkdir|creat|rmdir|access|chmod|chown|utime|link|unlink|symlink|readlink|stat|cat|simplewrite|quit] ");
    fgets(line, 128, stdin);
    line[strlen(line)-1] = 0;

    if (line[0]==0)
       continue;
    pathname[0] = 0;

    sscanf(line, "%s %s %s", cmd, pathname, ebuf);
    printf("cmd=%s pathname=%s\n", cmd, pathname);

    if (strcmp(cmd, "ls")==0)
    {
     ls(pathname);
    }
    else if (strcmp(cmd, "cd")==0)
    {
      chdir(pathname);
    }
    else if (strcmp(cmd, "pwd")==0)
    {
      //here we can see that cwd is clearly update by chdir
      //printf("RUN PWD, %d\n", running->cwd->ino);
      pwd(running->cwd);//always based off cwd
    }
    else if (strcmp(cmd, "creat")==0)
    {
      _creat(pathname, FILE_MODE);
    }
    else if (strcmp(cmd, "mkdir")==0)
    {
      _mkdir(pathname);
    }
    else if (strcmp(cmd, "rmdir")==0)
    {
      _rmdir(pathname);
    }
    else if (strcmp(cmd, "chmod")==0)
    {
      mchmod(pathname, ebuf);
    }
    else if (strcmp(cmd, "stat")==0)
    {
      mstat(pathname); 
    }
    else if (strcmp(cmd, "utime")==0)
    {
      chtime(pathname);
    }
    else if (strcmp(cmd, "access")==0)
    {
      access(pathname);
    }
    else if (strcmp(cmd, "chown")==0)
    {
      chown(pathname, ebuf);//ebuf is pathname, pathname is the new owner
    }
    else if (strcmp(cmd, "link")==0)
    {
      link(pathname, ebuf);//ebuf is pathname, pathname is the new owner
    }
    else if (strcmp(cmd, "unlink")==0)
    {
      unlink(pathname);//unlink two files
    }
    else if (strcmp(cmd, "readlink")==0)
    {
      int x = readlink(pathname, ebuf); 
      printf("Read %d bits\n", x); 
    }
    else if (strcmp(cmd, "symlink")==0)
    {
      symlink(pathname, ebuf); 
    }
    else if (strcmp(cmd, "cat")==0)
    {
      cat(pathname);  
    }
    else if (strcmp(cmd, "simplewrite")==0)
    {
      simplewrite(pathname, ebuf); 
    }
    else if (strcmp(cmd, "quit")==0)
    {
      quit();
    }

    
  }
}

int quit()
{
  int i;
  MINODE *mip;
  for (i=0; i<NMINODE; i++){
    mip = &minode[i];
    if (mip->refCount > 0)
      iput(mip);
  }
  exit(0);
}
