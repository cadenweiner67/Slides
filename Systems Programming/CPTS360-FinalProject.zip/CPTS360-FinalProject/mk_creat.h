#ifndef MK_CREAT_H_
#define MK_CREAT_H_
#include "type.h"
#include "util.h"
//function headers
int _mkdir(char * pathname); 

int _kmkdir(MINODE *parentmip, char * bname); 

int _creat(char * pathname, int mode); 

int enter_name(MINODE *parent, int ino, char *name, int mode);





#endif