#include "read.h"

int _read(int fd, char *buf, int nbytes)
{
    printf("ENTER READ\n");
    int count = 0; //this is the number of bytes read so far
    int offset = running->fd[fd]->offset; //keeping track of the offset
    int available = 1024 - offset; 
    
    
    //printf("ino == %d\n", running->fd[fd]->mptr->INODE.i_size);//file 1 size is 0
    int lblk = 0; //logical block
    int start = 0;
    char kbuf[BLKSIZE];  
    int blk = 0; 
    int remain = 0; 
    int ibuf[256]; 
    //running->fd[fd]->mptr->INODE;//here is the inode for the open file descriptor
    //I'm a bit confused because the sioze of the files inodes is 0
    //do we just have to check how many blocks are in use by it or something?



    printf("Available == %d\n", available); 
    printf("Offset == %d\n", offset); 


    while (nbytes && available)//read while there is still space
    {
        lblk = offset / BLKSIZE; 
        start = offset % BLKSIZE; 
        /*
        convert logical block number to physical block number
        steps 2 and 3
        */

        lblk = _map(running->fd[fd]->mptr->INODE, lblk);

        get_block(dev, lblk, kbuf); 
        char * cp = kbuf + start; //increment the address
        remain = BLKSIZE - start; //calculate the amount remaining
        

        while (remain)
        {
            //printf("buf == %s\n", buf);
            *buf++ = *cp++; //increment to the next
            offset++; 
            count++; //increment the two values
            remain--; 
            available--; //decrement these two values as we read
            if (nbytes == 0 || available == 0)
                break; //we have nothing more to read or we have read to our limit
        }
    }
    return count; //return the number of bytes read


}




int cat(char * pathname)
{
    printf("OPEN\n"); 
    int fd = myopen(pathname, 0); //open for read
    char mbuf[BLKSIZE]; 
    printf("READ\n");
    //printf("FD == %d\n",fd); 

    int n = _read(fd,mbuf,1024);
    printf("%s\n", mbuf); 

    printf("CLOSE\n");
    myclose(fd);
    return 1;
}