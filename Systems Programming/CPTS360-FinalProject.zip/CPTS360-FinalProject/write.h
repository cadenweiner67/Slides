#ifndef WRITE_H_
#define WRITE_H_
#include "type.h"
#include "util.h"
int _write(int fd, char *buf, int nbytes); 

int move(char * fileorigin, char * destinationfile);  

int simplewrite(char * pathname, char * buf); 


#endif