#include "rmdir.h"

int _rmdir(char * pathname)
{
    printf("rmdir command\n");

    /************ Algorithm of rmdir *************/
    // (1). get in-memory INODE of pathname:
    //get MINODE of pathname:
    int ino = getino(pathname);
    MINODE *mip = iget(dev, ino);
    // (2). verify INODE is a DIR (by INODE.i_mode field);
    if (!S_ISDIR(mip->INODE.i_mode))
    {
        printf("Error: INODE is not a DIR\n");
        return -1;
    }
    // minode is not BUSY (refCount = 1);


    if (mip->INODE.i_links_count > 2)
    {
        printf("Error: minode is busy: refCount = %d\n", mip->refCount);
        //return -1;
    }
    // verify DIR is empty (traverse data blocks for number of entries = 2);
    if (!DIRis_empty(mip))
    {
        printf("Error: Dir is not empty\n");
        return -1;
    }
    

    char bname[128]; 
    char dname[128]; 
    strcpy(bname, basename(pathname));//order matters, dirname canabalizes the string
    strcpy(dname, dirname(pathname)); 
    printf("Basename : %s , Dirname : %s\n", bname, dname); 
    int pino = getino(dname); 
    MINODE * pmip = iget(mip->dev, pino); 
    printf("PARENT MINODE REF COUNT == %d\n", pmip->refCount); 
    printf("CHILD MINODE REF COUNT == %d\n", mip->refCount); 




    // (4). /* get name from parent DIR’s data block
    // findmyname(pmip, ino, rname); //find name from parent DIR
    // Fig. 11.9 Sample outputs of project #2
    // 11.8 File System Level-1 Functions 337(5). remove rname from parent directory */
    
    
    for (int i = 0; i < 12; i++)
    {
        if (mip->INODE.i_block[i] == 0)
        {
            continue;
        }
        bdalloc(mip->dev, mip->INODE.i_block[i]);    
    }
    idalloc(mip->dev, mip->ino);
    mip->dirty = 1; 
    iput(mip);
    
    rm_child(pmip, bname);



    pmip->INODE.i_links_count--;
    // (6). dec parent links_count by 1; mark parent pimp dirty;
    pmip->dirty = 1; 
    iput(pmip);
    // (7). /* deallocate its data blocks and inode */
    
    return 0;
}

int rm_child(MINODE * pmip, char *rname)
{
    DIR *dp;
    DIR *priordp, *finaldp;
    char *cp, *priorcp;
    char buffer[BLKSIZE], temp[256];
    char *startptr, *endptr;
    INODE *ip = &pmip->INODE;
    
    for (int i = 0; i < 12; i++)
    {
        if (ip->i_block[i] != 0)
        {
            get_block(pmip->dev, ip->i_block[i], buffer);
            cp = buffer;
            dp = (DIR *)buffer;
            while (cp < buffer + BLKSIZE)
            {
                strncpy(temp, dp->name, dp->name_len);
                temp[dp->name_len] = 0;
                if (!strcmp(temp, rname))
                {
                    if (cp == buffer && cp + dp->rec_len == buffer + BLKSIZE)
                    {
                        
                        get_block(pmip->dev, bmap, buffer);
                        clr_bit(buffer, ip->i_block[i]-1); 
                        put_block(pmip->dev, bmap, buffer); 
                        incFreeBlocks(pmip->dev);  

                        ip->i_size -= BLKSIZE;
                        while (ip->i_block[i + 1] != 0 && i + 1 < 12)
                        {
                            i++;
                            get_block(pmip->dev, ip->i_block[i], buffer);
                            put_block(pmip->dev, ip->i_block[i - 1], buffer);
                        }
                    }
                    else if (cp + dp->rec_len == buffer + BLKSIZE)
                    {
                        priordp->rec_len += dp->rec_len;
                        put_block(pmip->dev, ip->i_block[i], buffer);
                    }
                    else
                    {
                        finaldp = (DIR *)buffer;
                        priorcp = buffer;
                        while (priorcp + finaldp->rec_len < buffer + BLKSIZE)
                        {
                            priorcp += finaldp->rec_len;
                            finaldp = (DIR *)priorcp;
                        }
                        finaldp->rec_len += dp->rec_len;
                        startptr = cp + dp->rec_len;
                        endptr = buffer + BLKSIZE;
                        memmove(cp, startptr, endptr - startptr);
                        put_block(pmip->dev, ip->i_block[i], buffer);
                    }
                    pmip->dirty = 1;
                    iput(pmip);
                    return 0;
                }
                priordp = dp;
                cp += dp->rec_len;
                dp = (DIR *)cp;
            }
        }
    }
    printf("ERROR: child not found\n");
    return -1;
}

int DIRis_empty(MINODE *mip)
{
    char buf[BLKSIZE], *p, t[256];
    DIR *dir;
    INODE *ipnode = &mip->INODE;
    // if enters here, dir is not empty
    if (ipnode->i_links_count > 2)
    {
        return 0;
    }
    else if (ipnode->i_links_count == 2)
    {
        for (int i = 0; i < 12; i++)
        {
            if (ipnode->i_block[i] == 0)
            {
                break;
            }
            get_block(mip->dev, mip->INODE.i_block[i], buf);
            dir = (DIR *)buf;
            p = buf;
            while (p < buf + BLKSIZE)
            {
                strncpy(t, dir->name, dir->name_len);
                t[dir->name_len] = 0;
                // if enters here, dir is not empty
                if (strcmp(t, ".") && strcmp(t, ".."))
                {
                    return 0;
                }
                p += dir->rec_len;
                dir = (DIR *)p;
            }
        }
    }
    // if gets here then dir is empty
    return 1;
}