#include "stat.h"

int mstat(char *pathname)
{
    int ino = getino(pathname);
    if (ino != 0)
    { 
        MINODE *mip = iget(dev, ino);

        printf("NAME: %s\n", basename(pathname));
        printf("Permissions: "); 
        if (S_ISDIR(mip->INODE.i_mode))
        {
            printf("d");
        }
        else if (S_ISLNK(mip->INODE.i_mode))
        {
            printf("l");
        }
        else if (S_ISREG(mip->INODE.i_mode))
        {
            printf("-");
        }
        
        //will print out the symbol if they have access
        //otherwise prints
        //goes from left to right, since we print
        //one at a time, we must print the left mostbits first
        if (mip->INODE.i_mode & (1 << 8)) //bit wise logical shift left compair the bits with those in the dir
        {
            printf("r");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 7))
        {
            printf("w");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 6))
        {
            printf("x");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 5))
        {
            printf("r");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 4))
        {
            printf("w");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 3))//compair bits
        {
            printf("x");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 2))//compairs bits
        {
            printf("r");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 1))//compairs bits
        {
            printf("w");
        }
        else
        {
            printf("-");
        }
        if (mip->INODE.i_mode & (1 << 0))//compairs bits
        {
            printf("x");
        }
        else
        {
            printf("-");
        }
        printf("\nINO: %d\n",ino);
        printf("LINKS: %d\n", mip->INODE.i_links_count);
        printf("MODE: %d, USER ID: %d, GROUP ID: %d, FLAGS: %d\n", mip->INODE.i_mode, mip->INODE.i_uid, mip->INODE.i_gid, mip->INODE.i_flags); 
        printf("SIZE: %d\n", mip->INODE.i_size); 
        printf("Blocks: %d\n", mip->INODE.i_blocks); 
        time_t timevar = mip->INODE.i_ctime; 
        printf("CREATION TIME: %s\n", ctime(&timevar)); 
        //its not printing access time properly 
        //I don't know why ctime only works for ->i_mtime
        timevar = mip->INODE.i_atime; 
        printf("ACCESS TIME: %s\n", ctime(&timevar)); 
        timevar = mip->INODE.i_mtime; 
        printf("Modify TIME: %s\n", ctime(&timevar)); 
        mip->dirty = 1; 
        iput(mip); 
    }
    else{
        printf("Not a valid file or directory\n"); 
    }
}
