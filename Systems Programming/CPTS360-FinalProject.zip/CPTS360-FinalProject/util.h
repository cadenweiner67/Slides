#ifndef UTIL_H_
#define UTIL_H_
#include "type.h"

// globals
extern MINODE minode[NMINODE];
extern MINODE *root;

extern PROC   proc[NPROC], *running;

extern char gpath[128]; // global for tokenized components
extern char *name[32];  // assume at most 32 components in pathname
extern int   n;         // number of component strings

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, inode_start;

int get_block(int dev, int blk, char *buf);

int put_block(int dev, int blk, char *buf);

MINODE *iget(int dev, int ino);

void iput(MINODE *mip);

int search(MINODE *mip, char *name);

int getino(char *pathname);

int findmyname(MINODE *parent, u32 myino, char *myname);

int findino(MINODE *mip, u32 *myino);

int ialloc(int dev); //allocates an inode

int balloc(int dev); //allocates a block

int tst_bit(char * buf, int bit);

int set_bit(char * buf, int bit);

//allocationg and dallocating node and inode
int decFreeInodes(int dev);

int decFreeBlocks(int dev);

int incFreeInodes(int dev);

int incFreeBlocks(int dev);

int clr_bit(char * buf, int bit);

int idalloc(int dev, int ino);

int bdalloc(int dev, int blocknum); // deallocate a block number

int get_mtable(int dev);

//mapping function for indirect and double indirect blocks
int _map(INODE inode, int lblk); 

#endif