#ifndef LINK_UNLINK_H_
#define LINK_UNLINK_H_
#include "type.h"
#include "util.h"

int link(char * oldfile, char * newfile); 

int unlink(char * pathname); 


#endif