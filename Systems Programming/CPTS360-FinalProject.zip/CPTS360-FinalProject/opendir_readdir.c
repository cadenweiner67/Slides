#include "opendir_readdir.h"


int opendir(char * pathname)
{
    return myopen(pathname, 0); //opens a directory for read
}

int myreaddir(int fd, DIR *udir)
{
    //similair to read so I will try and implement that first
}