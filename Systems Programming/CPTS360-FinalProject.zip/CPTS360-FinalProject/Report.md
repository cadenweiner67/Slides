# Final Report

### Benjamin Michaelis - ID# 11620581

### Caden Weiner - ID # 11620912

---

- [Final Report](#final-report)
  - [Section A. - Introduction](#section-a---introduction)
  - [Section B. - Design](#section-b---design)
  - [Section C. - Results](#section-c---results)
  - [Section D. - Conclusions](#section-d---conclusions)

---

## Section A. - Introduction

The goal of this project was to design and implement a Linux-compatible EXT2 file system. In order to do this we had to take everything that we learned throughout the semester and apply it into one cumulative project. In this we got to learn about different parts of implementations a file system, such as making directories and files through the manipulating the INode structure and the disk image and removing directories. We also learned about how files were stored in memory and on the disk and how they needed to be aware of where the following blocks were so they could access the appropriate contents and be allocated more space. Another one of our goals was too be able to link and unlink two files and to remove files that had no links left. We also had to implement other linux commands such as pwd, cd, ls, chmod, chown, utime, access, and stat. We also began to investigating opening, closing and lseek as well as beginning to research reading and writing to a file's INode. Through implementing these commands we were able to get much more familiar with the EXT2 file system.

## Section B. - Design

Overall to approach this file system we really broke apart the overall problem we had to solve (an entire file system) into different parts (basic file system tree, reading/writing file contents, etc) and then from there broke it down into individual commands that made the most sense to do first that would help check other commands correct implementation. To this end we began with mkdir and creat as they went hand in hand, followed by remove (this way we had mkdir/creat working to test remove functions with) Then we worked on links, chmod, utime and stat, before moving onto read and write. It was very helpful to have the functions cd, ls and pwd that we already made, as they allowed for us to visualize the behavior of the filesystem much more easily and understand where errors were occurring. After having a better understanding of rmdir and mkdir we created the symlink, readlink, link and unlink commands which were much easier to run and test now that we had built certain functions that they shared with rmdir and mkdir such as enter_child and rm_child.

## Section C. - Results

Running ./mkdisk and ls on root <break>
![](Images/Capture1.png)

Showing cd dir and creating a new file in that directory. <break>
![](Images/Capture2.png)

Linking the files newfile and newfile2. Newfile2 doesn’t exist so it creates that. <break>
![](Images/Capture3.png)

Ls to show the output and then unlinking newfile2 which decrements the link count. <break>
![](Images/Capture4.png)

Creating a symbolic link between newfile and the symbolicfile. <break>
![](Images/Capture5.png)

Ls to show the output of the previous command and reading the symbolic link. <break>
![](Images/Capture6.png)

Running chmod 1 on file1, changes the first permission bit. Chmod accepts octal. <break>
![](Images/Capture7.png)

Utime modifies the time on the current file, stat the file to show the change. <break>
![](Images/Capture8.png)

Change the owner and show access for file1. <break>
![](Images/Capture9.png)

Making a new directory newdir in the root. <break>
![](Images/Capture10.png)

Remove the newdir we previously created. Ls to demonstrate the change. <break>
![](Images/Capture11.png)

Unlink the file2 to remove it. <break>
![](Images/Capture12.png)

Unlink the file1 to remove it. <break>
![](Images/Capture13.png)

Remove the empty dir2 and ls the root to view the change. <break>
![](Images/Capture14.png)

Try to remove dir1, but it fails because dir1 has contents and a directory that has contents can’t be deleted. <break>
![](Images/Capture15.png)

Making a dir that already exists fails since you can’t use the same name for contents under a dir. <break>
![](Images/Capture16.png)

Navigating to the deepest directory and printing the path. <break>
![](Images/Capture17.png)

## Section D. - Conclusions

Overall, this lab was difficult but a lot easier working with a partner as well as once we broke problems down into smaller problems. This was particular useful when we ran into problems such as segmentation faults and then we could use a second pair of eyes to check for problems, and as well as this, because when we ran into a problem, because we implemented things with a small chunk of work at a time it was significantly easier to find the root of any problems we had. As well as this, we found difficulties with segfaults throughout the program as well as some edge cases with creation and removing functions not working as we would like which took a long time to debug and figure out exactly what was causing these edge case problems. The project provided a lot of learning opportunities and challenged us to make sure we understood what we were doing from both at a high and low level implementation. This project helped us to better understand both the debugging system in C as well as how file systems are set up and the data structures and functions that they utilize.
