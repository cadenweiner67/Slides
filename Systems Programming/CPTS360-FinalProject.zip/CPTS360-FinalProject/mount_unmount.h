#ifndef MOUNT_UNMOUNT_H_
#define MOUNT_UNMOUNT_H_
#include "type.h"

#endif