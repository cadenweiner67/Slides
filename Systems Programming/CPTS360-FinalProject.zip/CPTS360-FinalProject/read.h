#ifndef READ_H_
#define READ_H_
#include "type.h"
#include "util.h"
#include "open_close_lseek.h"
int _read(int fd, char *buf, int nbytes); 

int cat(char * pathname); 

#endif