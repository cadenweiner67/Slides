#include "write.h"

int _write(int fd, char *buf, int nbytes)
{
    int count = 0; 
    int lblk = 0; 
    int start = 0; 
    char kbuf[BLKSIZE]; 
    int remain = 0; 
    int offset = 0; 
    int blk = 0; 

    while(nbytes) // while we still have more to write
    {
        lblk = running->fd[fd]->offset / BLKSIZE;
        start = running->fd[fd]->offset % BLKSIZE;
        // step3 to do, convert lblk to physical block number
        lblk = _map(running->fd[fd]->mptr->INODE, lblk);
        
        get_block(dev, lblk, kbuf); //read the block from memory
        char * cp = kbuf + start; 
        remain = BLKSIZE - start;
        while (remain)
        {
            *cp++ = *buf++; //increment both the buf and cp
            offset++; // increment our counts and our offset for where we are writing
            count++; 
            remain--; //decrement the bits we need to 
            nbytes--; 
            if(offset > running->fd[fd]->mptr->INODE.i_size){
                running->fd[fd]->mptr->INODE.i_size++; //increment the size of the file as we write to it
            }
            if (nbytes <= 0)
            {
                break; //we can't write past the number of bits we set as the write limit
            }
        }
        put_block(dev, lblk, buf); 
        break; 
    }

    running->fd[fd]->mptr->dirty = 1; //mark as dirty since we changed the MINODE's contents

    return count; //returns the  count of bits written successfully
}

int simplewrite(char * pathname, char * buf)
{
    printf("OPEN\n"); 
    int fd = myopen(pathname, 1); //open for read
    char mbuf[BLKSIZE]; 
    printf("WRITE\n");
    //printf("FD == %d\n",fd); 

    int n = _write(fd,mbuf,1024);
    //printf("%s\n", mbuf); 

    printf("CLOSE\n");
    myclose(fd);
    return 1;




}