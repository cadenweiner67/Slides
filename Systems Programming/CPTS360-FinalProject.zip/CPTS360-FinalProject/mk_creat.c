#include "mk_creat.h"

int _mkdir(char * pathname)
{
    //currently, the search funuction works and indicates if the file has already been created
    printf("mkdir command\n");
    char bname[128]; 
    char dname[128]; 
    strcpy(bname, basename(pathname));//order matters, dirname canabalizes the string
    strcpy(dname, dirname(pathname)); 
    printf("Basename : %s , Dirname : %s\n", bname, dname); 
    int pino = getino(dname); 
    MINODE * parentmip = iget(dev, pino); 
    if (!S_ISDIR(parentmip->INODE.i_mode))
    {
        printf("Pathname cannot make a directory under a file\n"); 
        return -1; 
    }
    // MINODE * start; 
    // int rdev; 
    // if (pathname[0] == "/")
    // {
    //     start = root; 
    // }
    // else{//relative
    // start = running->cwd; 
    // rdev = running->cwd->dev;
    // }
    
    if (search(parentmip, bname) == 0) //checks if the base already exists under the parents path
    {
        printf("We can mkdir: %s\n", bname); 
        _kmkdir(parentmip, bname); 
        return 1; 
    }
    else //the node already exists
    {
        printf("This name already exists: %s\n",bname); 
        return -1; 
    }


    
}

int _kmkdir(MINODE *parentmip, char * bname)
{
    int ino = ialloc(dev);
    int blk = balloc(dev); //blk is bno
    printf("block %d, ino %d\n", blk, ino); 
    MINODE *mip = iget(dev, ino);
    INODE *ip = &mip->INODE;
    ip->i_mode = DIR_MODE;
    // 040755: DIR type and permissions
    ip->i_uid = running->uid; // owner uid
    ip->i_gid = running->gid; // group Id
    ip->i_size = BLKSIZE;
    // size in bytes
    ip->i_links_count = 2;
    // links count=2 because of . and ..
    ip->i_atime = ip->i_ctime = ip->i_mtime = time(0L);
    ip->i_blocks = 2;
    // LINUX: Blocks count in 512-byte chunks
    ip->i_block[0] = blk;//was bno I assume that meant block number
    // new DIR has one data block
    //ip->i_block[1] to ip->i_block[14] = 0;
    for (int i = 1; i < 15; i++)
    {
        ip->i_block[i] = 0;
    }
    // mark minode dirty
    mip->dirty = 1;
    // write INODE to disk
    iput(mip);


    char buf[BLKSIZE], *cp;
    bzero(buf, BLKSIZE); 
    //get_block(dev, blk, buf);
    DIR *dp = (DIR *)buf;
    dp->inode = ino; 
    
    int pino; 
    pino = findino(parentmip, &pino); 
    dp->inode = ino;
    dp->rec_len = 12;
    dp->name_len = 1;
    dp->name[0] = '.';
    cp+= dp->rec_len;
    dp = (char *)dp + 12;
    // make .. entry: pino=parent DIR ino, blk=allocated block
    // dp = (char *)dp + 12;
    dp->inode = pino;
    dp->rec_len = BLKSIZE-12;
    // rec_len spans block
    dp->name_len = 2;
    dp->name[0] = dp->name[1] = '.';
    //write the block back to the disk

    put_block(dev, blk, buf);
    enter_name(parentmip, ino, bname, DIR_MODE); 
    parentmip->refCount++; //increment the parents reference count by 1
    parentmip->dirty = 1;
    parentmip->INODE.i_links_count += 1; 
    iput(parentmip); 
}

int _creat(char * pathname, int mode)
{
    printf("creat command\n");
    char bname[128]; 
    char dname[128]; 
    strcpy(bname, basename(pathname));//order matters, dirname canabalizes the string
    strcpy(dname, dirname(pathname)); 
    printf("Basename : %s , Dirname : %s\n", bname, dname); 
    int pino = getino(dname); 
    MINODE * parentmip = iget(dev, pino); 
    if (!S_ISDIR(parentmip->INODE.i_mode))
    {
        printf("Pathname cannot make a file under a file\n"); 
        return -1; 
    }
    
    if (search(parentmip, bname) == 0) //checks if the base already exists under the parents path
    {
        printf("We can creat: %s\n", bname); 
        int ino = ialloc(dev);
        int blk = balloc(dev); //blk is bno
        printf("block %d, ino %d\n", blk, ino); 
        MINODE *mip = iget(dev, ino);
        INODE *ip = &mip->INODE;
        ip->i_mode = mode;
        // 040755: DIR type and permissions
        ip->i_uid = running->uid; // owner uid
        ip->i_gid = running->gid; // group Id
        ip->i_size = 0;
        // size in bytes
        ip->i_links_count = 1;//link count one and don't inc parents count
        // links count=2 because of . and ..
        ip->i_atime = time(0L);
        ip->i_ctime = time(0L);
        ip->i_mtime = time(0L);
        ip->i_blocks = 2;
        // LINUX: Blocks count in 512-byte chunks
        ip->i_block[0] = blk;//was bno I assume that meant block number
        // new DIR has one data block
        //ip->i_block[1] to ip->i_block[14] = 0;
        for (int i = 1; i < 15; i++)
        {
            ip->i_block[i] = 0;
        }
        // mark minode dirty
        mip->dirty = 1;
        // write INODE to disk
        iput(mip);

        enter_name(parentmip, ino, bname, mode); 
        return 1; 
    }
    else //the node already exists
    {
        printf("This file name already exists: %s\n",bname); 
        return -1; 
    }

    return 1; 
}



int enter_name(MINODE *parent, int ino, char *bname, int mode)
{
    char rbuf[BLKSIZE]; 
    char xbuf[BLKSIZE]; 
    DIR *dp; 
    char * cp; 
    int ideal_length; 
    int need_length; 
    int remain; 
    int i = 0;
    for(i = 0; i < 12; i++)
    {
        printf("Block %d\n", i); 
        bzero(rbuf, BLKSIZE); 
        bzero(xbuf, BLKSIZE); 
        if(parent->INODE.i_block[i] == 0)
        {
            break; //go to step five
        } 
        //printf("Getting Block"); 
        get_block(parent->dev, parent->INODE.i_block[i], rbuf); 
        dp = (DIR *)rbuf; 
        cp = rbuf;  
        //printf("Entering dir loop\n"); 

        if (dp->rec_len == BLKSIZE && strcmp(dp->name, "---------")==0)
        {
            printf("Special case for a new block\n\n\n\n"); 
            strcpy(dp->name, bname); 
            dp->file_type = mode; 
            dp->inode = ino; 
            dp->rec_len = BLKSIZE; 
            dp->name_len = strlen(bname);
            put_block(parent->dev, parent->INODE.i_block[i], rbuf);
            break; 
        }







        while (cp + dp->rec_len < rbuf + BLKSIZE)
        {
            //printf("loop: dpreclen %d\n", dp->rec_len); //observing behavior
            cp += dp->rec_len; 
            dp = (DIR *)cp; 
        }//to get dp to point at the end
        //printf("Finished dir loop\n"); 
        cp = (char * )dp;  
        ideal_length = 4*((8 + dp->name_len +3)/4); 
        need_length = 4*((8 + strlen(bname)+3)/4); 
        remain = dp->rec_len - ideal_length; 
        printf("ideal %d,need %d,remain %d\n", ideal_length, need_length, remain); 
        printf("BNAME %s\n", bname); 
        if (remain >= need_length)
        {
            printf("remain >= need_length\n"); 

            dp->rec_len = ideal_length;  //convert it to its ideal length
            cp += dp->rec_len; 
            dp = (DIR *)cp;

            printf("record is %d\n", dp->rec_len); 
            strcpy(dp->name, bname); 
            dp->file_type = mode; 
            dp->inode = ino; 
            dp->rec_len = remain; 
            dp->name_len = strlen(bname);
            // dp->rec_len = remain;
            //printf("%d, %d, %s \n", dp->name_len, dp->rec_len, dp->name); 

            put_block(parent->dev, parent->INODE.i_block[i], rbuf);
            //step 6
            
            // enter new entry as last ending 
            // trim the previous entries length to its ideal length
        }
        else if (parent->INODE.i_block[i+1] == 0){
            
            //ls_dir(running->cwd); 
            // //step 5
            printf("Not enough space to create entry, allocating another block\n"); 
            //create a new block
            //put that block onto the parent block
            // if (i + 1 < 12 && parent->INODE.i_block[i+1] == 0)
            // {
            //     int blk = balloc(parent->dev);
            //     parent->INODE.i_size += BLKSIZE; 
            //     parent->INODE.i_block[i+1] = blk; //allocate a newblock
            // }
            int blk = balloc(parent->dev);
            parent->INODE.i_size += BLKSIZE; 
            parent->INODE.i_block[i+1] = blk; 

            get_block(parent->dev, blk, xbuf); 
            dp = (DIR *)xbuf; 
            strcpy(dp->name, "---------"); 
            dp->file_type = mode; 
            dp->inode = ino; 
            dp->rec_len = BLKSIZE; 
            dp->name_len = strlen("---------");  
            put_block(parent->dev, blk, xbuf);
        }
        else{
            printf("This block is full checking next block\n"); 
        }
        put_block(parent->dev, parent->INODE.i_block[i], rbuf);
    }
    
    
}